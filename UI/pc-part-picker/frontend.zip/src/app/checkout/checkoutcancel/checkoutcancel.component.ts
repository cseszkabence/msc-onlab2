import { Component } from '@angular/core';

@Component({
  selector: 'app-checkoutcancel',
  imports: [],
  templateUrl: './checkoutcancel.component.html',
  styleUrl: './checkoutcancel.component.css'
})
export class CheckoutcancelComponent {

}
