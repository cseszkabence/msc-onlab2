export interface CheckoutItem {
    name: string;
    price: number;
    quantity: number;
  }