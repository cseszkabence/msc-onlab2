export interface CartItem {
  id?: number;
  userId?: string;
  partType: string;
  partId: number;
  quantity: number;
}