﻿namespace PCPartPicker.Models
{
    public class StripeModel
    {
        public string SecretKey { get; set; }
        public string PublishableKey { get; set; }
    }
}
