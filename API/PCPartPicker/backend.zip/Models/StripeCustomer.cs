﻿namespace PCPartPicker.Models
{
    public class StripeCustomer
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
