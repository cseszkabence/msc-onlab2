﻿namespace PCPartPicker.Interfaces
{
    public interface IComponent
    {
        int Id { get; set; }
    }
}
